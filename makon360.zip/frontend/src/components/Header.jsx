import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Header() {
  const { authenticated, logout } = useAuth();

  return (
    <header style={{ display: 'flex', justifyContent: 'space-between', padding: '16px', borderBottom: '1px solid #ddd' }}>
      <Link to="/" style={{ fontWeight: 'bold', textDecoration: 'none', color: 'inherit' }}>Makon360</Link>
      <div>
        {authenticated ? (
          <>
            <Link to="/create-listing" style={{ marginRight: '16px' }}>+ Yangi e'lon</Link>
            <button onClick={logout}>Chiqish</button>
          </>
        ) : (
          <>
            <Link to="/login" style={{ marginRight: '16px' }}>Kirish</Link>
            <Link to="/register">Ro'yxatdan o'tish</Link>
          </>
        )}
      </div>
    </header>
  );
}

export default Header;