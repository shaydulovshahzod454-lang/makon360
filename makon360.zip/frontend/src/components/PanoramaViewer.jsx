import { useEffect, useRef } from 'react';
import 'pannellum/build/pannellum.css';
import 'pannellum/build/pannellum.js';

function PanoramaViewer({ imageUrl, hotspots = [], onHotspotClick, editMode = false, onPanoramaClick }) {
  const viewerRef = useRef(null);
  const containerId = 'panorama-container';

  useEffect(() => {
    if (!imageUrl) return;

    const pannellumHotspots = hotspots.map((h) => ({
      id: `hotspot-${h.id}`,
      pitch: h.pitch,
      yaw: h.yaw,
      type: 'custom',
      cssClass: 'custom-hotspot',
      createTooltipFunc: (hotSpotDiv) => {
        hotSpotDiv.innerHTML = `<div class="hotspot-marker" title="${h.label || ''}">➜</div>`;
        hotSpotDiv.style.cursor = 'pointer';
        hotSpotDiv.onclick = (e) => {
          e.stopPropagation();
          onHotspotClick && onHotspotClick(h.target_room);
        };
      },
    }));

    viewerRef.current = window.pannellum.viewer(containerId, {
      type: 'equirectangular',
      panorama: imageUrl,
      autoLoad: true,
      hotSpots: pannellumHotspots,
    });

    // Tahrirlash rejimida - panorama ustida bosilganda koordinatani olish
    if (editMode && onPanoramaClick) {
      const handleClick = (e) => {
        const coords = viewerRef.current.mouseEventToCoords(e);
        // coords = [pitch, yaw]
        onPanoramaClick({ pitch: coords[0], yaw: coords[1] });
      };

      viewerRef.current.on('mousedown', handleClick);
    }

    return () => {
      if (viewerRef.current) {
        viewerRef.current.destroy();
      }
    };
  }, [imageUrl, hotspots, onHotspotClick, editMode, onPanoramaClick]);

  return (
    <div>
      {editMode && (
        <p style={{ background: '#ffe58a', padding: '8px', marginBottom: '8px' }}>
          Xarita rejimida: xonaga o'tish nuqtasini belgilash uchun panorama ustida istalgan joyga bosing.
        </p>
      )}
      <div id={containerId} style={{ width: '100%', height: '500px' }} />
    </div>
  );
}

export default PanoramaViewer;