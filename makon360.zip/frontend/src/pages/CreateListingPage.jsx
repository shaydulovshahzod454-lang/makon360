import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';

function CreateListingPage() {
  const { id } = useParams(); // agar id bo'lsa - tahrirlash rejimi
  const isEditMode = Boolean(id);

  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({
    title: '', description: '', price: '', address: '',
    contact_phone: '', category: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(isEditMode);
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/categories/').then((res) => setCategories(res.data));
  }, []);

  // Tahrirlash rejimida - mavjud ma'lumotlarni yuklab, formaga to'ldirish
  useEffect(() => {
    if (isEditMode) {
      api.get(`/listings/${id}/`).then((res) => {
        const data = res.data;
        setForm({
          title: data.title,
          description: data.description,
          price: data.price,
          address: data.address,
          contact_phone: data.contact_phone,
          category: data.category?.id || '',
        });
        setLoading(false);
      });
    }
  }, [id, isEditMode]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (isEditMode) {
        await api.patch(`/listings/${id}/`, form);
        navigate(`/listing/${id}`);
      } else {
        const res = await api.post('/listings/', form);
        navigate(`/listing/${res.data.id}/add-room`);
      }
    } catch (err) {
      console.error(err);
      setError('Xatolik yuz berdi. Barcha maydonlarni tekshiring.');
    }
  };

  if (loading) return <p>Yuklanmoqda...</p>;

  return (
    <div style={{ maxWidth: '500px', margin: '40px auto' }}>
      <h2>{isEditMode ? "E'lonni tahrirlash" : "Yangi e'lon qo'shish"}</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '12px' }}>
          <label>Sarlavha</label>
          <input name="title" value={form.title} onChange={handleChange} style={{ width: '100%', padding: '8px' }} required />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Tavsif</label>
          <textarea name="description" value={form.description} onChange={handleChange} style={{ width: '100%', padding: '8px' }} required />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Narx ($)</label>
          <input type="number" name="price" value={form.price} onChange={handleChange} style={{ width: '100%', padding: '8px' }} required />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Manzil</label>
          <input name="address" value={form.address} onChange={handleChange} style={{ width: '100%', padding: '8px' }} required />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Aloqa telefoni</label>
          <input name="contact_phone" value={form.contact_phone} onChange={handleChange} style={{ width: '100%', padding: '8px' }} required />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Toifa</label>
          <select name="category" value={form.category} onChange={handleChange} style={{ width: '100%', padding: '8px' }} required>
            <option value="">Tanlang</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit" style={{ padding: '8px 16px' }}>
          {isEditMode ? 'Saqlash' : "Keyingi qadam: xonalar qo'shish"}
        </button>
      </form>
    </div>
  );
}

export default CreateListingPage;