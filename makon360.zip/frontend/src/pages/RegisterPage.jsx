import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { register } from '../services/auth';
import { useAuth } from '../context/AuthContext';

function RegisterPage() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await register(username, email, password);
      // Ro'yxatdan o'tgandan so'ng avtomatik login qilamiz
      await login(username, password);
      navigate('/');
    } catch (err) {
      console.error(err);
      if (err.response?.data) {
        // Backend'dan kelgan xato xabarlarini ko'rsatish (masalan "username band" yoki "parol juda oddiy")
        const messages = Object.values(err.response.data).flat().join(' ');
        setError(messages || "Ro'yxatdan o'tishda xatolik yuz berdi");
      } else {
        setError("Ro'yxatdan o'tishda xatolik yuz berdi");
      }
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '40px auto' }}>
      <h2>Ro'yxatdan o'tish</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '12px' }}>
          <label>Foydalanuvchi nomi</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Parol</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit" style={{ padding: '8px 16px' }}>Ro'yxatdan o'tish</button>
      </form>
      <p style={{ marginTop: '12px' }}>
        Akkountingiz bormi? <Link to="/login">Kirish</Link>
      </p>
    </div>
  );
}

export default RegisterPage;