import { useEffect, useState, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../services/api';
import PanoramaViewer from '../components/PanoramaViewer';

function ManageHotspotsPage() {
  const { id } = useParams(); // listing id
  const [listing, setListing] = useState(null);
  const [currentRoomId, setCurrentRoomId] = useState(null);
  const [pendingCoords, setPendingCoords] = useState(null); // {pitch, yaw}
  const [targetRoomId, setTargetRoomId] = useState('');
  const [label, setLabel] = useState('');
  const [error, setError] = useState('');

  const loadListing = () => {
    api.get(`/listings/${id}/`).then((res) => {
      setListing(res.data);
      if (!currentRoomId) {
        const entryRoom = res.data.rooms.find((r) => r.is_entry_point) || res.data.rooms[0];
        setCurrentRoomId(entryRoom?.id);
      }
    });
  };

  useEffect(() => {
    loadListing();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!listing) return <p>Yuklanmoqda...</p>;

  const currentRoom = listing.rooms.find((r) => r.id === currentRoomId);
  const otherRooms = listing.rooms.filter((r) => r.id !== currentRoomId);

  const handlePanoramaClick = useCallback((coords) => {
    setPendingCoords(coords);
    setError('');
  }, []);

  const handleCreateHotspot = async (e) => {
    e.preventDefault();
    if (!pendingCoords || !targetRoomId) {
      setError('Iltimos, avval panorama ustida joy belgilang va qaysi xonaga o\'tishini tanlang.');
      return;
    }

    try {
      await api.post('/hotspots/', {
        room: currentRoomId,
        target_room: targetRoomId,
        pitch: pendingCoords.pitch,
        yaw: pendingCoords.yaw,
        label: label,
      });
      setPendingCoords(null);
      setTargetRoomId('');
      setLabel('');
      loadListing(); // yangilangan hotspotlar ro'yxatini olish
    } catch (err) {
      console.error(err);
      setError('Hotspot yaratishda xatolik yuz berdi.');
    }
  };

  const handleDeleteHotspot = async (hotspotId) => {
    try {
      await api.delete(`/hotspots/${hotspotId}/`);
      loadListing();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h2>{listing.title} — Xonalarni bog'lash</h2>

      <div style={{ marginBottom: '16px' }}>
        <label>Joriy xona: </label>
        <select value={currentRoomId || ''} onChange={(e) => { setCurrentRoomId(Number(e.target.value)); setPendingCoords(null); }}>
          {listing.rooms.map((r) => (
            <option key={r.id} value={r.id}>{r.name}</option>
          ))}
        </select>
      </div>

      {currentRoom && (
        <PanoramaViewer
          imageUrl={currentRoom.panorama_image}
          hotspots={currentRoom.hotspots}
          editMode={true}
          onPanoramaClick={handlePanoramaClick}
        />
      )}

      {pendingCoords && (
        <form onSubmit={handleCreateHotspot} style={{ marginTop: '16px', padding: '16px', background: '#f5f5f5' }}>
          <p>Belgilangan nuqta: pitch={pendingCoords.pitch.toFixed(2)}, yaw={pendingCoords.yaw.toFixed(2)}</p>
          <div style={{ marginBottom: '8px' }}>
            <label>Qaysi xonaga o'tkazish: </label>
            <select value={targetRoomId} onChange={(e) => setTargetRoomId(e.target.value)} required>
              <option value="">Tanlang</option>
              {otherRooms.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>
          <div style={{ marginBottom: '8px' }}>
            <label>Yorliq (ixtiyoriy, masalan "Yotoqxonaga o'tish"): </label>
            <input value={label} onChange={(e) => setLabel(e.target.value)} style={{ padding: '6px' }} />
          </div>
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <button type="submit" style={{ padding: '8px 16px' }}>Hotspot yaratish</button>
        </form>
      )}

      <div style={{ marginTop: '24px' }}>
        <h3>Mavjud hotspotlar (shu xonada):</h3>
        {currentRoom?.hotspots.length === 0 && <p>Hali hotspot yo'q.</p>}
        <ul>
          {currentRoom?.hotspots.map((h) => (
            <li key={h.id}>
              {listing.rooms.find((r) => r.id === h.target_room)?.name || 'Noma\'lum xona'}
              {' '}(pitch: {h.pitch.toFixed(1)}, yaw: {h.yaw.toFixed(1)})
              {' '}
              <button onClick={() => handleDeleteHotspot(h.id)} style={{ marginLeft: '8px' }}>O'chirish</button>
            </li>
          ))}
        </ul>
      </div>

      <Link to={`/listing/${id}`} style={{ display: 'inline-block', marginTop: '16px' }}>
        Tayyor — e'lonni ko'rish
      </Link>
    </div>
  );
}

export default ManageHotspotsPage;