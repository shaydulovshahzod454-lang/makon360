import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import PanoramaViewer from '../components/PanoramaViewer';
import { useAuth } from '../context/AuthContext';

function ListingDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { authenticated } = useAuth();
  const [listing, setListing] = useState(null);
  const [currentRoomId, setCurrentRoomId] = useState(null);
  const [deleteError, setDeleteError] = useState('');

  useEffect(() => {
    api.get(`/listings/${id}/`).then((res) => {
      setListing(res.data);
      const entryRoom = res.data.rooms.find((r) => r.is_entry_point) || res.data.rooms[0];
      setCurrentRoomId(entryRoom?.id);
    });
  }, [id]);

  const handleDelete = async () => {
    const confirmed = window.confirm("Rostdan ham bu e'lonni o'chirmoqchimisiz? Bu amalni ortga qaytarib bo'lmaydi.");
    if (!confirmed) return;

    try {
      await api.delete(`/listings/${id}/`);
      navigate('/');
    } catch (err) {
      console.error(err);
      setDeleteError("O'chirishda xatolik yuz berdi. Ehtimol bu sizning e'loningiz emas.");
    }
  };

  if (!listing) return <p>Yuklanmoqda...</p>;

  const currentRoom = listing.rooms.find((r) => r.id === currentRoomId);

  return (
    <div>
      <h1>{listing.title}</h1>
      <p>{listing.description}</p>
      <p><strong>Narx:</strong> {listing.price} $</p>
      <p><strong>Manzil:</strong> {listing.address}</p>
      <p><strong>Aloqa:</strong> {listing.contact_phone}</p>

      {currentRoom && (
        authenticated ? (
          <PanoramaViewer
            imageUrl={currentRoom.panorama_image}
            hotspots={currentRoom.hotspots}
            onHotspotClick={(targetRoomId) => setCurrentRoomId(targetRoomId)}
          />
        ) : (
          <div style={{
            width: '100%', height: '500px', background: '#222', color: '#fff',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            gap: '12px'
          }}>
            <p style={{ fontSize: '18px' }}>360° ko'rish uchun ro'yxatdan o'ting yoki tizimga kiring</p>
            <div style={{ display: 'flex', gap: '12px' }}>
              <Link to="/register" style={{ padding: '8px 16px', background: '#fff', color: '#222', textDecoration: 'none', borderRadius: '4px' }}>
                Ro'yxatdan o'tish
              </Link>
              <Link to="/login" style={{ padding: '8px 16px', border: '1px solid #fff', color: '#fff', textDecoration: 'none', borderRadius: '4px' }}>
                Kirish
              </Link>
            </div>
          </div>
        )
      )}

      {deleteError && <p style={{ color: 'red' }}>{deleteError}</p>}

      <button
        onClick={() => navigate(`/listing/${id}/edit`)}
        style={{ marginTop: '16px', marginRight: '8px', padding: '8px 16px' }}
      >
        Tahrirlash
      </button>
      <button
        onClick={handleDelete}
        style={{ marginTop: '16px', padding: '8px 16px', backgroundColor: '#d33', color: '#fff', border: 'none', cursor: 'pointer' }}
      >
        E'lonni o'chirish
      </button>
    </div>
  );
}

export default ListingDetailPage;