import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

function HomePage() {
  const [listings, setListings] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [ordering, setOrdering] = useState('');

  useEffect(() => {
    api.get('/categories/').then((res) => setCategories(res.data));
  }, []);

  useEffect(() => {
    setLoading(true);

    const params = {};
    if (search) params.search = search;
    if (category) params.category = category;
    if (minPrice) params.min_price = minPrice;
    if (maxPrice) params.max_price = maxPrice;
    if (ordering) params.ordering = ordering;

    api.get('/listings/', { params })
      .then((res) => setListings(res.data))
      .catch((err) => console.error('Xatolik:', err))
      .finally(() => setLoading(false));
  }, [search, category, minPrice, maxPrice, ordering]);

  return (
    <div>
      <h1>Makon360 — Uylar ro'yxati</h1>

      {/* Qidiruv va filter paneli */}
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '24px', padding: '16px', background: '#f5f5f5' }}>
        <input
          type="text"
          placeholder="Qidirish (sarlavha, manzil...)"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ padding: '8px', flex: '1 1 200px' }}
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)} style={{ padding: '8px' }}>
          <option value="">Barcha toifalar</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <input
          type="number"
          placeholder="Min narx"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
          style={{ padding: '8px', width: '100px' }}
        />
        <input
          type="number"
          placeholder="Max narx"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
          style={{ padding: '8px', width: '100px' }}
        />
        <select value={ordering} onChange={(e) => setOrdering(e.target.value)} style={{ padding: '8px' }}>
          <option value="">Saralash</option>
          <option value="price">Narx: arzondan qimmatga</option>
          <option value="-price">Narx: qimmatdan arzonga</option>
          <option value="-created_at">Eng yangi</option>
        </select>
      </div>

      {loading ? (
        <p>Yuklanmoqda...</p>
      ) : listings.length === 0 ? (
        <p>Hech qanday e'lon topilmadi.</p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
          {listings.map((listing) => (
            <Link
              key={listing.id}
              to={`/listing/${listing.id}`}
              style={{ border: '1px solid #ddd', padding: '12px', textDecoration: 'none', color: 'inherit' }}
            >
              {listing.main_image && (
                <img src={listing.main_image} alt={listing.title} style={{ width: '100%', height: '150px', objectFit: 'cover' }} />
              )}
              <h3>{listing.title}</h3>
              <p>{listing.price} $</p>
              <p>{listing.address}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export default HomePage;