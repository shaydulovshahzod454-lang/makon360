import { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';

function AddRoomPage() {
  const { id } = useParams();
  const [name, setName] = useState('');
  const [image, setImage] = useState(null);
  const [isEntryPoint, setIsEntryPoint] = useState(false);
  const [rooms, setRooms] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!image) {
      setError('Iltimos, panorama rasm tanlang');
      return;
    }

    const formData = new FormData();
    formData.append('listing', id);
    formData.append('name', name);
    formData.append('panorama_image', image);
    formData.append('is_entry_point', isEntryPoint);

    try {
      const res = await api.post('/rooms/', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setRooms([...rooms, res.data]);
      setName('');
      setImage(null);
      setIsEntryPoint(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      console.error(err);
      setError('Rasm yuklashda xatolik yuz berdi');
    }
  };

  return (
    <div style={{ maxWidth: '500px', margin: '40px auto' }}>
      <h2>Xonalarni qo'shish</h2>
      <p>Har bir xona uchun nomi va 360° panorama rasmini yuklang.</p>

      <form onSubmit={handleSubmit} style={{ marginBottom: '24px' }}>
        <div style={{ marginBottom: '12px' }}>
          <label>Xona nomi (masalan: Oshxona)</label>
          <input value={name} onChange={(e) => setName(e.target.value)} style={{ width: '100%', padding: '8px' }} required />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>Panorama rasm</label>
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={(e) => setImage(e.target.files[0])}
            required
          />
        </div>
        <div style={{ marginBottom: '12px' }}>
          <label>
            <input type="checkbox" checked={isEntryPoint} onChange={(e) => setIsEntryPoint(e.target.checked)} />
            {' '}Bu xonadan tur boshlanadi (kirish nuqtasi)
          </label>
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit" style={{ padding: '8px 16px' }}>Xonani qo'shish</button>
      </form>

      <h3>Qo'shilgan xonalar:</h3>
      <ul>
        {rooms.map((r) => (
          <li key={r.id}>{r.name} {r.is_entry_point && '(kirish nuqtasi)'}</li>
        ))}
      </ul>

      <button onClick={() => navigate(`/listing/${id}/hotspots`)} style={{ marginTop: '16px', padding: '8px 16px' }}>
        Keyingi qadam — xonalarni bog'lash
      </button>
    </div>
  );
}

export default AddRoomPage;