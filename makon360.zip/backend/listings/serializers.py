from rest_framework import serializers
from .models import Category, Listing, Room, Hotspot
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password


class HotspotSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hotspot
        fields = ['id', 'room', 'target_room', 'yaw', 'pitch', 'label']

class RoomSerializer(serializers.ModelSerializer):
    hotspots = HotspotSerializer(many=True, read_only=True)

    class Meta:
        model = Room
        fields = ['id', 'listing', 'name', 'panorama_image', 'is_entry_point', 'hotspots']

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        request = self.context.get('request')
        if not (request and request.user and request.user.is_authenticated):
            representation['panorama_image'] = None
        return representation
    
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']

class ListingListSerializer(serializers.ModelSerializer):
    """Ro'yxat sahifasi uchun - qisqa ma'lumot (tezroq yuklanadi)"""
    category = CategorySerializer(read_only=True)
    main_image = serializers.SerializerMethodField()

    class Meta:
        model = Listing
        fields = ['id', 'title', 'price', 'address', 'category', 'main_image']

    def get_main_image(self, obj):
        first_room = obj.rooms.first()
        if first_room and first_room.panorama_image:
            request = self.context.get('request')
            return request.build_absolute_uri(first_room.panorama_image.url)
        return None


class ListingDetailSerializer(serializers.ModelSerializer):
    """Bitta e'lon sahifasi uchun - to'liq ma'lumot, barcha xonalar bilan"""
    category = CategorySerializer(read_only=True)
    rooms = RoomSerializer(many=True, read_only=True)

    class Meta:
        model = Listing
        fields = [
            'id', 'title', 'description', 'price', 'address',
            'category', 'contact_phone', 'rooms', 'created_at'
        ]

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, validators=[validate_password])
    email = serializers.EmailField(required=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password']

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("Bu email allaqachon ro'yxatdan o'tgan.")
        return value

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password'],
        )
        return user