from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, ListingViewSet, RoomViewSet, HotspotViewSet, RegisterView

router = DefaultRouter()
router.register('categories', CategoryViewSet)
router.register('listings', ListingViewSet)
router.register('rooms', RoomViewSet)
router.register('hotspots', HotspotViewSet)

urlpatterns = router.urls + [
    path('register/', RegisterView.as_view(), name='register'),
]