from django.contrib import admin
from .models import Category, Listing, Room, Hotspot

admin.site.register(Category)
admin.site.register(Listing)
admin.site.register(Room)
admin.site.register(Hotspot)